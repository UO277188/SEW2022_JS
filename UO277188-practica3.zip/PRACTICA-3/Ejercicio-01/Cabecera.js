"use strict"
class Asignatura {
    nombre = "Software y estándares en la Web";
    titulacion = "Grado en Ingeniería Informática del Software";
    centro = "Escuela de Ingeniería Informática";
    universidad = "Universidad de Oviedo";
    curso = "2022-2023";
    alumno = "Diego Villa García";
    email = "uo277188@uniovi.es";
}

var asignatura = new Asignatura();