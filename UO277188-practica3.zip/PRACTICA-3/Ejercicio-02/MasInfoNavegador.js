document.write("Versión: ")
document.write(infoNavegador.version);
document.write(", plataforma: ")
document.write(infoNavegador.plataforma);
document.write(", vendedor: ")
document.write(infoNavegador.vendedor);
document.write(", agente: ")
document.write(infoNavegador.agente);