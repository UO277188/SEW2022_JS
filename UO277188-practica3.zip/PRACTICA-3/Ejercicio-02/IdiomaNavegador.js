document.write("Idioma: ")
document.write(infoNavegador.idioma);