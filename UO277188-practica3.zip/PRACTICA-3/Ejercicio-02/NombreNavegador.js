document.write("Nombre: ")
document.write(infoNavegador.nombre);